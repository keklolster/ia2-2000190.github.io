// Global variables for username and password
const validUsername = "user123";
const validPassword = "password123";

// Track login attempts
let attempts = 0;

// Get the login form and error message elements
const loginForm = document.getElementById("loginForm");
const errorMessage = document.getElementById("errorMessage");

loginForm.addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent default form submission

    const usernameInput = document.getElementById("username").value;
    const passwordInput = document.getElementById("password").value;

    // Check if the fields are filled and if the password is at least 8 characters long
    if (usernameInput === "" || passwordInput === "") {
        errorMessage.textContent = "All fields are required.";
        return;
    }

    if (passwordInput.length < 8) {
        errorMessage.textContent = "Password must be at least 8 characters long.";
        return;
    }

    // Check if the entered username and password match the valid ones
    if (usernameInput === validUsername && passwordInput === validPassword) {
        localStorage.setItem('loggedIn', 'true'); // Set login status
        alert('Login successful! Redirecting to Products page...');
        window.location.href = "products.html"; // Redirect to Products page on successful login
    } else {
        attempts++; // Increment the login attempts

        // Check if attempts have reached 3
        if (attempts >= 3) {
            // Redirect to Error page after 3 failed attempts
            window.location.href = "error.html";
        } else {
            errorMessage.textContent = `Incorrect credentials. You have ${3 - attempts} attempt(s) left.`;
        }
    }
});
