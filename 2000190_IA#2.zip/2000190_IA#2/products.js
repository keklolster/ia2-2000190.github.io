// Global arrays to store product data for 9 products
const products = [
    { name: "Basic Cable Package", price: 50, quantityId: "basicQty" },
    { name: "Premium Cable Package", price: 100, quantityId: "premiumQty" },
    { name: "Sports Package", price: 30, quantityId: "sportsQty" },
    { name: "Family Package", price: 40, quantityId: "familyQty" },
    { name: "Movie Buff Package", price: 70, quantityId: "movieBuffQty" },
    { name: "Kids Package", price: 25, quantityId: "kidsQty" },
    { name: "News Package", price: 20, quantityId: "newsQty" },
    { name: "Sports HD Package", price: 50, quantityId: "sportsHDQty" },
    { name: "International Package", price: 60, quantityId: "internationalQty" }
];

// Tax and discount rates
const TAX_RATE = 0.15; // 15% tax
const DISCOUNT_THRESHOLD = 200; // Discount applied if total is above this
const DISCOUNT_RATE = 0.10; // 10% discount

// Function to calculate the total
function calculateTotal() {
    let subtotal = 0;
    let tax = 0;
    let discount = 0;

    // Calculate the subtotal by iterating through products
    products.forEach(product => {
        const quantity = document.getElementById(product.quantityId).value;
        subtotal += product.price * quantity;
    });

    // Apply tax
    tax = subtotal * TAX_RATE;

    // Apply discount if applicable
    if (subtotal > DISCOUNT_THRESHOLD) {
        discount = subtotal * DISCOUNT_RATE;
    }

    // Final total calculation
    const total = subtotal + tax - discount;

    // Store the invoice data in localStorage for use in the invoice page
    const invoiceData = {
        subtotal: subtotal.toFixed(2),
        tax: tax.toFixed(2),
        discount: discount.toFixed(2),
        total: total.toFixed(2)
    };
    localStorage.setItem('invoiceData', JSON.stringify(invoiceData));

    // Redirect to invoice page
    window.location.href = 'invoice.html';
}


document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("checkoutBtn").addEventListener("click", calculateTotal);

    document.getElementById("cancelBtn").addEventListener("click", function() {
        // Reset the quantity values to 1
        products.forEach(product => {
            document.getElementById(product.quantityId).value = 1;
        });
        alert("Selection has been reset.");
    });

    document.getElementById("exitBtn").addEventListener("click", function() {
        window.location.href = 'home.html'; // Redirect to the home page
    });
});
