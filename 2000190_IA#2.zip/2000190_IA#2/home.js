// Check if the user is logged in
function checkLogin() {
    const isLoggedIn = localStorage.getItem("isLoggedIn");

    // Redirect based on login status
    if (isLoggedIn === "true") {
        window.location.href = "products.html"; // Redirect to Products page if logged in
    } else {
        window.location.href = "login.html"; // Redirect to Login page if not logged in
    }
}

function simulateLogin() {
    localStorage.setItem("isLoggedIn", "true");
}


function simulateLogout() {
    localStorage.removeItem("isLoggedIn");
}
